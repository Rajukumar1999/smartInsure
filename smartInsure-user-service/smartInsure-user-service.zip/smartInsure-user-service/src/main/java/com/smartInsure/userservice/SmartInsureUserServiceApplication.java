package com.smartInsure.userservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartInsureUserServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartInsureUserServiceApplication.class, args);
	}

}
